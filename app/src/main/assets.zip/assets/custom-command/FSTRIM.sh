fstrim /data
fstrim /data
fstrim /system
fstrim /system
fstrim /cache
fstrim /cache
sm fstrim
