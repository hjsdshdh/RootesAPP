# Only Scene 4.4+
# 这里可以放一些工具函数，它会在安装配置文件时自动被提取到与 powercfg.sh 同一目录下
# 因此，你可以在powercfg.sh 中引用它