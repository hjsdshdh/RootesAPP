#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


echo "0|默认"
echo "Native|原生安卓样式"
