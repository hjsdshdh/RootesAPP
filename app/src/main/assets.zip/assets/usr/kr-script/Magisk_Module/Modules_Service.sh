echo 玩机百宝箱官方源
echo Magisk源（需要网络环境）