#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


echo "0|默认"
echo "BiliBili|B站Toast"
echo "BiliBili2|B站Toast_2"
echo "DianShi|电视机Toast"
