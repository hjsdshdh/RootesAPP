#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


rm -rf "$APK_Name_list"
am start -n Han.GJZS/com.root.system.DialogActivity
