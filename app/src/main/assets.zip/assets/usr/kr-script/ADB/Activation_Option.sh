#本脚本由　by Han | 情非得已c，编写
#应用于玩机百宝箱上


echo "HeiYu|黑阈"
echo "XiaoHeiWu|小黑屋"
echo "Shizuku"
echo "IceBox|冰箱"
echo "apkinstaller|安装狮 - 静默安装-DPM模式"
echo "dpmapkinstaller|安装狮-DPM"
echo "taichi|太极阴阳之门"
echo "KFMark|使用快否激活器激活「快否」"
echo "AutoHz"
#echo "Tasker"
echo "PermissionDog|权限狗 AppOps"
echo "AirFrozen|AirFrozen「空调狗」"
echo "LiuTiGesture|流体手势"
echo "One_Plus|激活一加隐藏的屏幕刷新率选项"
echo "Samsung_Small_white_strip_enable|启用三星设备小白条沉浸"
echo "Samsung_Small_white_strip_disable|禁用三星设备小白条沉浸"
echo "Freeform_ON|开启Freeform「多窗口模式」"
echo "Freeform_OFF|关闭Freeform「多窗口模式」"
